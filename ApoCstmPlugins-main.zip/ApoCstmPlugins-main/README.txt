README: Running the Application
Overview
This application requires different privilege levels to run based on the version of Windows you are using. Below are the instructions on how to properly run the application on both Windows 11 and Windows 10.

Prerequisites
Windows 11: Must be run as an Administrator.
Windows 10: Should be run without Administrator privileges.
Instructions for Windows 11
On Windows 11, the application requires Administrator privileges to function correctly. To run the application as an Administrator:

Right-click the application executable file.
Select Run as administrator from the context menu.
If prompted by User Account Control (UAC), click Yes to allow the application to make changes to your device.
Instructions for Windows 10
On Windows 10, Administrator privileges are not necessary. To run the application without Administrator rights:

Double-click the application executable file to launch it.
The application will run with the current user permissions and should not request elevated privileges.
Troubleshooting
Windows 11: If the application does not run correctly even after selecting "Run as administrator," try right-clicking on the executable, selecting Properties, and under the Compatibility tab, check the box that says Run this program as an administrator.

Windows 10: If the application requires administrator access unexpectedly, ensure you're not using any shortcut or compatibility settings that force it to run as administrator.